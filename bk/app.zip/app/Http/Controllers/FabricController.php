<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Models\Fabric;
use App\Models\VendorFabric;
use App\Models\Brand;
use App\Models\VendorBrand;
use App\Models\UserPackage;
use App\Jobs\FabricJob;
use App\Jobs\FabricJobNew;
use Yajra\Datatables\Datatables;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Config, Illuminate\Support\Facades\Storage;
use App\Jobs\TailoriFabricSyncJob;
use App\Jobs\TailoriFabricImageSyncJob;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\StyleAttributeController;
use Illuminate\Support\Facades\Http;
use App\Models\Vendor;
header('Access-Control-Allow-Origin: *');

class FabricController extends Controller
{
    private $appKey;
    private $client;

    public function __construct()
    {
        $this->middleware('auth');
        $this->client = new Client;
        $request = $this->client->get(Config::get('constants.API_URL').'LoginUsers?UserName='.Config::get('constants.API_USERNAME').'&PasswordHash='.Config::get('constants.API_PASSWORD'));
        $this->appKey = $request->getBody()->getContents();
		// $_SESSION["AppKey"] =$this->appKey;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        // $vendors = User::where('user_group', 2)->where('status', 1)->pluck('name', 'user_uid'); shubham Added purpose: split table
        $vendors = User::where('user_group', 2)->where('status', 1)->with('vendor')->get()->pluck('name', 'vendor.user_uid');
        
        return view('admin.fabric.index')->withVendors($vendors);
    }
    /**
     * Load all fabrics on listing page
     */
    public function loadFabrics(Request $request){
        $fabrics = $this->fetchFabrics();
        return Datatables::of($fabrics)
        ->editColumn('description', function($fabrics){
            return $fabrics['description']!=''?$fabrics['description']:'N/A';
        })
        ->editColumn('product_type', function($fabrics){
            return $fabrics['product_type']!=''?$fabrics['product_type']:'N/A';
        })
        ->make('true');
    }

    /**
     * Fetch all fabrics
     */
    public function fetchFabrics(){
        $fabrics = Fabric::all();
        return $fabrics;
    }
    public function getBrands()
    {
        $brand = [];//shubham
        $vendorID = auth()->user()->vendor_id;
        $_SESSION["AppKey"] = Vendor::where('vendor_id', $vendorID)->value('user_uid');
        if(auth()->user()->user_group !=1)
        {
            $brandArr = VendorBrand::with('brand')->where('vendor_id',auth()->user()->vendor_id)->get()->toArray();

            $i = 0;
            $lastElement = end($brandArr);
            $vendorBrandArr = [];

            foreach ($brandArr as $key => $value) 
            {
                $brand[$i]['brand'] = $value['brand']['brand_name'];
                $i++;
                if($value == $lastElement) 
                {
                    $brand[$i]['brand'] ='TEXTRONIC';//Admin Brand
                }

            }
        }
        else
        {
            $brand = Brand::select('brand_name as brand')->where('is_active',1)->get(['brand'])->toArray();
        }
        return $brand;
    }
    public function fabricGrid(Request $request){

        $brand           = $this->getBrands();

        // $brand = array(array(
        //     "brand" => "TEXTRONIC")
        // );
        // $isPackageActive = UserPackage::where('user_id', auth()->user()->id)->where('is_active', 1)->count();
        $inStoreCount    = 0;
        $offStoreCount   = 0;
        
        $vendorBrandArr  = array_map(function ($ar) {return $ar['brand'];}, $brand);

        if(auth()->user()->user_group !=1)
        {
            $inStoreCount     = VendorFabric::where('vendor_id', auth()->user()->vendor_id)->where('is_active',1)->get()->count();

            $inStorefabricIds = VendorFabric::where('vendor_id', auth()->user()->vendor_id)->where('is_active',1)->get(['fabric_id'])->pluck('fabric_id');

            $offStoreCount    = Fabric::whereNotIn('fabric_id',$inStorefabricIds)->whereIn('brand',$vendorBrandArr)->get()->count(); 
             //$offStoreCount = VendorFabric::where('vendor_id', auth()->user()->id)->where('is_active',0)->get()->count();
        }
        $allStoreCount = Fabric::whereIn('brand',$vendorBrandArr)->get()->count();
        
        // if($isPackageActive == 1)
        // if(auth()->user()->user_group !=1)
        // {
            $fabrics = Fabric::where(function($query){
                            $query->WhereNull('vendor_key')->orWhere('vendor_key',auth()->user()->user_uid);
                       })->orderBy('fabric_id', 'desc');

            $fabricColors = Fabric::select('color')->WhereNull('vendor_key')->orWhere('vendor_key',auth()->user()->user_uid)->distinct()->get()->toArray();
            
            if($request['search'] != '' || $request['product'] != '' || $request['wear'] != '' || $request['colors'] != '' || $request['view'] != '' ){
    
                if($request['view'] != '')
                {
                    if($request['view'] == 'in_store'){
                       
                        $fabricIds  = VendorFabric::where('vendor_id', auth()->user()->vendor_id)->where('is_active',1)->get(['fabric_id'])->pluck('fabric_id');

                        $fabrics    = Fabric::whereIn('fabric_id', $fabricIds);   
                    }
                    else if($request['view'] == 'off_store')
                    {
                        $inStorefabricIds   = VendorFabric::where('vendor_id', auth()->user()->vendor_id)->where('is_active',1)->get(['fabric_id'])->pluck('fabric_id');

                        $fabrics            = Fabric::whereNotIn('fabric_id',$inStorefabricIds); 
                    }
                }
                
                if($request['search'] != '')
                {
                     $fabricsCount      = Fabric::where('fabric_name', 'LIKE', "%" .$request['search']. "%")->get()->count();

                     if($fabricsCount)
                     {
                        $fabrics = Fabric::where('fabric_name', 'LIKE', "%" .$request['search']. "%");
                     }
                     else
                     {
                        $fabricId = VendorFabric::where('fabric_name', 'LIKE', "%" .$request['search']. "%")->where('vendor_id', auth()->user()->vendor_id)->get(['fabric_id'])->pluck('fabric_id');
                        
                        if(count($fabricId))
                        {
                            $fabrics = Fabric::where('fabric_id', $fabricId);
                        }
                        else
                        {
                            $fabrics = Fabric::where('fabric_name', 'LIKE', "%" .$request['search']. "%");
                        }
                     }
                    
                }
                
                if($request['product'] != '')
                {
                    $type = json_decode($request['product'], true);
                    $fabrics = $fabrics->whereIn('product_type', $type);
                }
                if($request['wear'] != '')
                {
                    $wearType = json_decode($request['wear'], true);
                    $fabrics = $fabrics->whereIn('wear_type', $wearType);
                }
                if($request['brand'] != '')
                {
                    $requestBrand = json_decode($request['brand'],true);
                    $fabrics = $fabrics->whereIn('brand', $requestBrand);
                }
                if($request['colors'] != '')
                {
                    $colors = json_decode($request['colors'], true);
                    $fabrics = $fabrics->whereIn('color', $colors);
                }
                $fabrics = $fabrics->with('vendorFabrics')->whereIn('brand',$vendorBrandArr)->paginate(20);
            }
            else
            {
                $fabrics = $fabrics->with('vendorFabrics')->whereIn('brand',$vendorBrandArr)->paginate(20);
            }
    
            if($request->ajax())
            {
                return view('admin.fabric.filtered')->withFabrics($fabrics)->withInStore($inStoreCount)->withOffStore($offStoreCount)->withAllStore($allStoreCount);
            }
            else
            {
                // $hostUrl = User::where('id', auth()->user()->id)->value('store_url');; shubham Added purpose: split table
                $vendorDetails = Vendor::where('vendor_id', auth()->user()->vendor_id)->get();
                $hostUrl = $vendorDetails[0]->store_url;
                auth()->user()->fabric_upload_limit = $vendorDetails[0]->fabric_upload_limit;
                return view('admin.fabric.grid')->withFabrics($fabrics)->withColors($fabricColors)->withHost($hostUrl)->withBrand($brand)->withInStore($inStoreCount)->withOffStore($offStoreCount)->withAllStore($allStoreCount);
            }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storemulti(Request $request){
        $brandArr = VendorBrand::with('brand')->where('vendor_id',auth()->user()->vendor_id)->get()->toArray();
        $brand_name = $brandArr[0]['brand']['brand_name'];
        $requestData[]=$request['FabricData'];
       $i = 0;
        foreach($requestData as $fabarray){
                $requestData[0]['key']=isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid;  
                $requestData[0]['designerName']=isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid; 
                $requestData[0]['propertyValues']['brand']=$brand_name;
                $i++;
            }
            $returnData =  $this->dispatch(new FabricJob($requestData));
            return json_encode($returnData);
    }
    public function fetchFabricAndElementDetails(Request $request,$returnData ) {
        // 1. Retrieve fabric details and other properties from $requestData and $returnData
        $requestData = $request->get('FabricData');
        $brandArr = VendorBrand::with('brand')->where('vendor_id', auth()->user()->vendor_id)->first();
        $brandName = $brandArr->brand->brand_name ?? '';
        
        // Extract fabric details from returnData
        $fabricId = $returnData[0]['Id'][0] ?? null; // Assuming the first element is the fabric ID
        
        // Extract key values from requestData
        $fabricDetails = [
            'fabricId' => $fabricId,
            'imageName' => $requestData['propertyValues']['imageName'] ?? null,
            'description' => $requestData['propertyValues']['description'] ?? null,
            'libraryName' => $requestData['propertyValues']['libraryName'] ?? null,
            'brand' => $brandName,
        ];
    
        $vendorId = Auth::id();
    
        $styleController = new StyleAttributeController();
        $packageId = UserPackage::where('user_id', $vendorId)->value('package_id');
        $products = $styleController->getTailoriProducts($packageId);
    
        $allProductDetails = [];    
    
        foreach ($products as $product) {
            $productId = $product['product_id'] ?? null;
    
            if ($productId) {
                // Get Elements for the product
                $elementRequest = new Request(['productId' => $productId]);
                $elements = json_decode($styleController->getTailoriElements($elementRequest), true);
    
                $elementDetails = [];
    
                // For each element, get associated styles and attributes
                foreach ($elements as $element) {
                    $elementId = $element['id'];
                    $elementName = $element['element_name'];
    
                    // Get Styles and Attributes for the element
                    $styleRequest = new Request(['elementId' => $elementId]);
                    $stylesWithAttributes = json_decode($styleController->getTailoriStyles($styleRequest), true);
    
                    $elementDetails[] = [
                        'elementId' => $elementId,
                        'elementName' => $elementName,
                        'styles' => $stylesWithAttributes,
                    ];
                }
    
                // Add product, element, and style data to the main array
                $allProductDetails[] = [
                    'productId' => $productId,
                    'productName' => $product['tailoriProducts']['name'] ?? null,
                    'elements' => $elementDetails,
                ];
            }
        }
    
        // 3. Combine fabric details and elements with styles into a single JSON response
        $completeDetails = [
            'fabricDetails' => $fabricDetails,
            'vendorId' => $vendorId,
            'packageId' => $packageId,
            'products' => $allProductDetails,
        ];
    
        return response()->json($completeDetails);
    }
    public function store(Request $request)
    {   
        // if(isset($request['vendor']))
        // {
        //     $userUid = User::where('id', $request['vendor'])->value('user_uid');
        // }
        
        $requestParam = $request->all();
        $image = $request->file('fabric_image');
        $input['imagename'] = 'test.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/images');
        $image->move($destinationPath, $input['imagename']);
        $imageData = file_get_contents(public_path('/images/').'test.'.$image->getClientOriginalExtension());
        $imageData = base64_encode($imageData);
        $brandArr = VendorBrand::with('brand')->where('vendor_id',auth()->user()->vendor_id)->get()->toArray();
        $brand_name = $brandArr[0]['brand']['brand_name'];
        $requestData[] = [
            'key'         => isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid,
            'imageName'   => $request['fabric_name'],
            'designerName'=> isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid,
            'libraryName' => $request['product_type'],
            'description' => isset($request['description'])?$request['description']:"",
            //'price'       => $request['price'],
            'fabricImage'  => preg_replace('#^data:image/[^;]+;base64,#', '', $imageData),
            'propertyValues'=>[
                'DESIGN'    => $request['design_pattern'],
                'COLOUR'    => $request['color'],
                'blend'     => $request['fabric_blend'],
                'brand'     => $brand_name,
            ],
        ];
        
        $job = (new FabricJob($requestData));

        $returnData = dispatch($job);

        if($returnData){
            return response()->json(['message_code'=> 1,"message"=> "Fabric uploaded successfully"],200);
        }
        else{
            return response()->json(['message_code'=> 0,"message"=> "Fabric not uploaded"],200);
        }
    }

    public function tailoriFabricSync(Request $request)
    {   
        /**
         * Job to sync Tailori fabrics to application
         */
        $tailoriFabricSyncJob = (new TailoriFabricSyncJob($this->appKey));
        dispatch($tailoriFabricSyncJob);

        /**
         * Job to sync Tailori fabrics images to application
         */
        /* $fabrics = Fabric::all()->toArray();
        
        foreach($fabrics as $fabric){
            if( !Storage::disk('public')->exists( 'thumbnail/'.$fabric['fabric_image'] ) ){
                $tailoriFabricImageSyncJob = (new TailoriFabricImageSyncJob($this->appKey, $fabric['tailori_fabric_id'], $fabric['id']));
                dispatch($tailoriFabricImageSyncJob);
            }
        } */
    }

    /**
     * Get fabrics and sync it to the opencart store
     */
    public function tailoriFabricSyncToStore(Request $request){
        $fabricIds = $request['fabricIds'];
        $fabrics = Fabric::whereIn('tailori_fabric_code', $fabricIds)->with('vendorFabrics')->get()->toArray();
        $fabric = [];
        $i = 0;
        foreach($fabrics as $eachFabric){
            foreach($eachFabric as $key=>$value){
                $fabric[$i][$key] = $value;
            }
            $i++;
        }
        return json_encode($fabric);
    }

    /**
     * Set or update the vendor fabrics with active status
     */
    public function setVendorFabricStatus(Request $request){
        if( count($request['fabricIds']) > 0 ){
            foreach($request['fabricIds'] as $fabricId){
                VendorFabric::updateOrCreate([ 'fabric_id' => $fabricId, 'vendor_id' => auth()->user()->vendor_id ], [
                    'vendor_id' => auth()->user()->vendor_id,
                    'fabric_id' => $fabricId,
                    'is_active' => 1
                ]);
            }
            return 1;
        }
        return 0;
    }

    /**
     * Get requested fabric
     */
    public function getRequestedFabric(Request $request){

        $fabricId = $request['fabricId'];

        $vendorFabricCount = VendorFabric::where('vendor_id', auth()->user()->vendor_id)
        ->where('fabric_id', $fabricId)->count();
        
        if($vendorFabricCount > 0){
          
            $fabricRecord = VendorFabric::where('vendor_id', auth()->user()->vendor_id)
            ->where('fabric_id', $fabricId)
            ->with('fabric')
            ->get()
            ->toArray();
           
            $fabricRecord = [
                'id' => $fabricRecord[0]['fabric_id'],
                'tailori_fabric_code' => $fabricRecord[0]['fabric']['tailori_fabric_code'],
                'fabric_name' => $fabricRecord[0]['fabric_name'],
                'description'  => $fabricRecord[0]['description'],
                'price'  => $fabricRecord[0]['price'],
            ];
        }
        else{
           
            $fabricRecord = Fabric::where('id', $fabricId)->get(['id', 'tailori_fabric_code', 'fabric_name', 'price', 'description'])->toArray();
            $fabricRecord = [
                'id' => $fabricRecord[0]['id'],
                'tailori_fabric_code' => $fabricRecord[0]['tailori_fabric_code'],
                'fabric_name' => $fabricRecord[0]['fabric_name'],
                'description'  => $fabricRecord[0]['description'],
                'price'  => $fabricRecord[0]['price'],
            ];
        }
       
        return $fabricRecord;
    }

	/*
        * Send the Configuration to service for uploading --> Pravesh
    */
    public function forwardConfigData(Request $request)
    {
        $client = new Client;
        $url = "http://172.16.10.69/Tailori/CustomerService_cdn/api/UploadConfigurationJson";
        
        $configData = $request->input('configData'); // Retrieve configData from the request
        $token = $request->input('_token'); // Optional: Validate the CSRF token

        // Ensure that configData is properly encoded as JSON
        $response = $client->request('POST', $url, [
            'json' => $configData, // This automatically sets Content-Type to application/json
            'headers' => [
                'X-CSRF-TOKEN' => $token // Optional: If you need CSRF token in headers
            ]
        ]);
        
        return response()->json(json_decode($response->getBody()->getContents()), $response->getStatusCode());
    }
    /**
     * Update vendor fabric details 
     */
    public function vendorFabricUpdate(Request $request){

        $isCreated = VendorFabric::updateOrCreate([ 'fabric_id' => $request['hd_fabric_id'], 'vendor_id'=> auth()->user()->vendor_id ], [
            'vendor_id' => auth()->user()->vendor_id,
            'fabric_name' => $request['hd_fabric_name'],
            'price' => $request['hd_price'],
            'description' => $request['hd_fabric_description']!=''?$request['hd_fabric_description']:NULL,
        ]);

        if($isCreated->wasRecentlyCreated == false)
        {

            $active = VendorFabric::where('id',$isCreated->id)->first()->is_active;
            
            if($active){

                $fabricCode = Fabric::where('id', $request['hd_fabric_id'])->value('tailori_fabric_code');
                
                // $storeUrl = User::where('id', auth()->user()->id)->value('store_url'); commented Pravesh for new vendor working
                $storeUrl = Vendor::where('vendor_id', auth()->user()->ivendor_id)->value('store_url');
                $url = $storeUrl.'index.php?route=tailori/custom/updateFabric';
                
                $response = ['exist'=>1,'tailori_fabric_code' => $fabricCode, 'storeUrl' => $url, 'price' => $request['hd_price'], 'fabric_name' => $request['hd_fabric_name'], 'description' => $request['hd_fabric_description'] ];
            }
            else{
                $response = ['exist'=>0];
            }
        }
        else
        {
            $response = ['exist'=>0];
        }


        return json_encode($response);
        
    }

    public function removeVendorFabric(Request $request)
    {
        $fabricId     = $request['fabrics'];

        if(count($fabricId)>0)
        {
            
            $fabrics = Fabric::whereIn('tailori_fabric_code', $fabricId)->pluck('id')->toArray();
            
           // VendorFabric::whereIn('fabric_id', $fabrics)->where('vendor_id', auth()->user()->id)->delete(); //Vijay
            
            // $storeUrl = User::where('id', auth()->user()->id)->value('store_url');commented Pravesh for new vendor working
            $storeUrl = Vendor::where('vendor_id', auth()->user()->vendor_id)->value('store_url');
            $url = $storeUrl.'index.php?route=tailori/custom/removeFabric';
            if( count($fabricId) > 0 ){//Vijay
                foreach($fabrics  as $fabricIdData){
                    VendorFabric::updateOrCreate([ 'fabric_id' => $fabricIdData, 'vendor_id' => auth()->user()->vendor_id ], [
                        'vendor_id' => auth()->user()->vendor_id,
                        'fabric_id' => $fabricIdData,
                        'is_active' => 0
                    ]);
                }
            }
            return json_encode(['message'=>'Fabric removed successfully','url'=>$url,'sku'=>$fabricId]);
        }
        else
        {
            return json_encode(['message'=>'Invalid Request']);
        }
    }
    //Vijay Remove Fabric From Vendor Panel 
    public function DeleteFromVendorPanel(Request $request)
    {
        
         $fabricId     = $request['fabricID'];
        array_unshift($fabricId,isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid);
         $fabrics = Fabric::whereIn('tailori_fabric_code',$fabricId)->pluck('id')->toArray();         
        VendorFabric::whereIn('fabric_id', $fabrics)->where('vendor_id', auth()->user()->vendor_id)->delete();
         Fabric::whereIn('id', $fabrics)->where('vendor_key', isset($request['vendor'])?$request['vendor']:Auth::user()->user_uid)->delete();       
      
        $job = (new FabricJobNew($fabricId ));

        $returnData = dispatch($job);

         if($returnData){
             return response()->json(['message_code'=> 1,"message"=> "Fabric deleted successfully"],200);}
         else{ return response()->json(['message_code'=> 0,"message"=> "Fabric not uploaded"],200);}
	}

    public function createFabricJSON(Request $request)
    {
        try {
            // Get the vendor ID
            $vendorId = auth()->user()->vendor_id;
    
            // Fetch vendor fabrics
            $vendorFabrics = VendorFabric::where('vendor_id', $vendorId)->get();
    
            // Fetch vendor brand
            $vendorBrand = VendorBrand::with('brand')
                ->where('vendor_id', $vendorId)
                ->first();
    
            if (!$vendorBrand) {
                return response()->json(['message' => 'Vendor Brand not found'], 404);
            }
    
            $vendorName = $vendorBrand->brand->brand_name;
    
            // Map product types to their specific options
            $productOptions = [
                'Shirt' => ['Shirt', 'Thread Hole', 'Button'],
                'Suit' => ['Suit', 'Inner Lining', 'Button Thread', 'Button'],
                'Waistcoat' => ['Waistcoat', 'Inner Lining', 'Button Thread', 'Button'],
                'Jacket' => ['Jacket', 'Inner Lining', 'Button Thread', 'Button'],
                'Bundy' => ['Bundy', 'Button'],
                'Bandhgala' => ['Bandhgala', 'Button Thread', 'Button'],
                'Trouser' => ['Trouser'],
            ];
    
            // Get product type dynamically from the request
            $desiredProductType = $request['text'];
            if (!isset($productOptions[$desiredProductType])) {
                return response()->json(['message' => 'Invalid product type'], 400);
            }
    
            // Create a map of fabric_id to is_active from VendorFabrics
            $vendorFabricMap = $vendorFabrics->pluck('is_active', 'fabric_id')->toArray();
    
            // Fetch fabrics based on product type
            $fabricData = Fabric::whereIn('id', array_keys($vendorFabricMap))
                ->whereIn('product_type', $productOptions[$desiredProductType]) // Match related product options
                ->get()
                ->map(function ($fabric) use ($vendorFabricMap) {
                    $fabric->is_active = $vendorFabricMap[$fabric->id] ?? null; // Add is_active to fabric
                    return $fabric;
                });
    
            $data = [
                'vendor_name' => $vendorName,
                'fabrics' => $fabricData->toArray(),
            ];
    
            // Generate JSON for download
            $fileName = "fabric_{$vendorName}.json";
            $headers = [
                'Content-Type' => 'application/json',
                'Content-Disposition' => "attachment; filename={$fileName}",
            ];
    
            // Send JSON data to external service
            $externalUrl = "http://172.16.10.69/Tailori/CustomerService_cdn/api/UploadFabricJson";
            $client = new Client();
    
            $response = $client->post($externalUrl, [
                'json' => $data,
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-CSRF-TOKEN' => csrf_token(),
                ],
            ]);
    
            $apiResponse = json_decode($response->getBody(), true);
    
            // Return JSON file for download if the API call succeeds
            return response()->streamDownload(function () use ($data) {
                echo json_encode($data, JSON_PRETTY_PRINT);
            }, $fileName, $headers);
    
        } catch (\Exception $e) {
            return response()->json(['message' => 'Error occurred: ' . $e->getMessage()], 500);
        }
    }
}
