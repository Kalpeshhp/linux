<?php

namespace App\Http\Controllers;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Exception;
class SubscriptionController extends Controller
{

    public function getSubscription($vendorId)
    {
        $validator = Validator::make(['vendorId' => $vendorId], [
            'vendorId' => 'required|integer'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        try {
            $subscription = Subscription::where('vendor_id', $vendorId)
                ->where('islatest', 1)
                ->select('fabric_limit', 'start_date', 'duration_in_months', 'isactive')
                ->first();
            if ($subscription) {
                return response()->json($subscription, 200);
            } else {
                return response()->json(null, 200);
            }
        } catch (Exception $e) {
            return response()->json(['message' => $e], 404);
        }
    }

    public function storeSubscription(Request $request)
    {
        $requestData = $request->all();

        $validator = Validator::make($requestData, [
            'vendorId' => 'required|integer',
            'fabric_limit' => 'required|integer',
            'start_date' => 'required|date',
            'duration' => 'required|integer',
            'status' => 'required|int'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        try {
            $vendorId = (int) $requestData['vendorId'];
            $durationInMonths = (int) $requestData['duration'];
            $end_date = Carbon::parse($requestData['start_date'])->addMonthNoOverflow($durationInMonths)->subDay()->format('Y-m-d');
            
            Subscription::where('vendor_id', $vendorId)
                ->where('islatest', 1)
                ->update(['islatest' => 0]);


            $lastVersion = Subscription::where('vendor_id', $vendorId)
                ->orderByDesc('version')
                ->value('version');


            $subscription = new Subscription();
            $subscription->vendor_id = $vendorId;
            $subscription->fabric_limit = $requestData['fabric_limit'];
            $subscription->duration_in_months = $durationInMonths;
            $subscription->version = $lastVersion ? $lastVersion + 1 : 1;
            $subscription->islatest = 1;
            $subscription->start_date = $requestData['start_date'];
            $subscription->end_date = $end_date;
            $subscription->isactive = (int)$requestData['status'];
            $subscription->save();

            if ($subscription) {
                return response()->json(['message' => 'Subscription created successfully'], 200);
            } else {
                return response()->json(['message' => 'Subscription creation failed'], 400);
            }
        } catch (Exception $e) {
            return response()->json(['message' => $e], 404);
        }
    }
}
