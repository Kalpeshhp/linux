<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jobs\TailoriProductSyncJob;
use App\Jobs\TailoriProductElementSyncJob;
use App\Jobs\TailoriProductElementStyleSyncJob;
use App\Jobs\TailoriProductElementStyleAttributeSyncJob;
use App\Jobs\TailoriStyleImageSyncJob;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Config;
use App\Models\TailoriProduct;
use App\Models\TailoriProductElement;
use App\Models\TailoriProductElementStyle;
use App\Models\VendorPackageAttributeSelection;
header('Access-Control-Allow-Origin: *');

class TailoriAssetSyncController extends Controller
{   
    private $appKey;
    private $client;

    public function __construct()
    {
        $this->middleware('auth');
        $this->client = new Client;
        $request = $this->client->get(Config::get('constants.API_URL').'LoginUsers?UserName='.Config::get('constants.API_USERNAME').'&PasswordHash='.Config::get('constants.API_PASSWORD'));
        $this->appKey = $request->getBody()->getContents();
    }
    /**
     * Sync tailori products
     */
    public function tailoriProductSync(Request $request){

        $job = (new TailoriProductSyncJob($this->appKey));

        dispatch($job)->onQueue('products');

        $this->tailoriProductElementSync();
    }
    /**
     * Sync tailori product elements
     */
    public function tailoriProductElementSync(){
        $products = TailoriProduct::select('id', 'tailori_product_code', 'product_name', 'is_active')->where('is_active', 1)->get()->toArray();
        if($products){
            foreach ($products as $product) {
                $job = (new TailoriProductElementSyncJob($this->appKey, $product['tailori_product_code'], $product['id']));
                dispatch($job)->onQueue('product_elements')->delay(now()->addSeconds(1));
            }
            $this->tailoriProductElementStyleSync();
        }
    }
    /**
     * Sync tailori element styles
     */
    public function tailoriProductElementStyleSync(){
        $elements = TailoriProductElement::select('id', 'product_id', 'tailori_element_code', 'is_active')->where('is_active', 1)->get()->toArray();
        if($elements){
            foreach($elements as $element){
                $job = (new TailoriProductElementStyleSyncJob($this->appKey, $element[ 'tailori_element_code'], $element['id']));
                dispatch($job)->onQueue('product_element_styles')->delay(now()->addSeconds(1));
            }
            $this->tailoriProductElementStyleAttributeSync();
        }
    }
    /**
     * Sync tailori style attributes
     */
    public function tailoriProductElementStyleAttributeSync(){
        $styles = TailoriProductElementStyle::select('id', 'element_id', 'tailori_style_code', 'style_name', 'is_active')->where('is_active', 1)->get()->toArray();
        if($styles){
            foreach($styles as $style){
                $job = (new TailoriProductElementStyleAttributeSyncJob($this->appKey, $style['tailori_style_code'], $style['id']));
                dispatch($job)->onQueue('product_element_style_attributes')->delay(now()->addSeconds(1));
            }
        }
    }

    public function syncImages(){
        $job = (new TailoriStyleImageSyncJob($this->appKey));
        dispatch($job)->onQueue('style_image_sync')->delay(now()->addSeconds(1));
    }

    /**
     * Get product with all possible elements, styles & attributes
     */
    public function getTailoriProducts(){
        $products = TailoriProduct::select('id', 'tailori_product_code', 'product_name')
        ->where('is_active', 1)
        ->with([ 'productElements' => 
            function($query){ 
                $query->select('id', 'product_id', 'tailori_element_code', 'element_name')
                ->with([ 'elementStyles' => 
                    function($query){ 
                        $query->select('id', 'element_id', 'tailori_style_code', 'style_name')
                        ->with([ 'styleAttributes' => 
                            function($query){ 
                                $query->select('id', 'style_id', 'tailori_attribute_code', 'attribute_name'); 
                            }]); 
                    }]);
            }])
        ->get()
        ->toJson();
    }

}