<?php

return [
	'api_key' 	=> 'a64960d6e4652e91a0cfc3537d1965de',
	'password' 	=> 'fd4c2daaa8780cbd4f5fc33c1dd2fc94',
	'secret' 	=> '14f2647b8fdc8cafb6d0f7cb36ca4e18',
	'domain' 	=> 'flying-changes-bespoke-jackets.myshopify.com',
	'product_type' => ['Customise']
];