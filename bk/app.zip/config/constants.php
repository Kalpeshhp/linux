<?php

/* return [
	'API_URL' => 'http://textronic.online/TailoriAPI_Platform/v1/',
	'API_USERNAME' => 'Tailoridemolong',
	'API_PASSWORD' => '1234',
	'TAILORI_PRODUCT_API_URL' => 'http://textronic.online/TailoriAPI_Platform/v1/Product?',
	'TAILORI_PRODUCT_ELEMENT_API_URL' => 'http://textronic.online/Tailoriapi/v1/Details?',
	'TAILORI_PRODUCT_ELEMENT_STYLE_API_URL' => 'http://textronic.online/Tailoriapi/v1/Options?',
	'TAILORI_PRODUCT_ELEMENT_STYLE_ATTRIBUTE_API_URL' => 'http://textronic.online/Tailoriapi/v1/Features?',
	'SWATCH_API_URL' => 'http://textronic.online/TailoriAPI_Platform/v1/Swatches?',
	'SWATCH_IMAGE_API_URL' => 'http://textronic.online/TailoriAPI_Platform/v1/swatchimage?',
	'STORE_URL' => 'http://127.0.0.1/opencart/upload/'
]; */


return [
	'API_URL' => 'https://tsaas.textronic.online/v1/',
	'API_USERNAME' => 'Tdsplatform',
	'API_PASSWORD' => '1234',
	'TAILORI_PRODUCT_API_URL' => 'https://tsaas.textronic.online/v1/Product?',
	'TAILORI_PRODUCT_ELEMENT_API_URL' => 'https://tsaas.textronic.online/v1/Details?',
	'TAILORI_PRODUCT_ELEMENT_STYLE_API_URL' => 'https://tsaas.textronic.online/v1/Options?',
	'TAILORI_PRODUCT_ELEMENT_STYLE_ATTRIBUTE_API_URL' => 'https://tsaas.textronic.online/v1/Features?',
	'TAILORI_PRODUCT_ELEMENT_IMAGES' => 'https://tsaas.textronic.online/api/Products/',
	'SWATCH_API_URL' => 'https://tsaas.textronic.online/v1/Swatches?',
	'STORE_URL' => 'http://127.0.0.1/opencart/upload/',
	'TAILORI_Monogram_Placement_API_URL' => 'https://tsaas.textronic.online/v1/MonogramPlacement?',
	'TAILORI_Monogram_Font_API_URL' => 'https://tsaas.textronic.online/v1/MonogramFont?',
	'TAILORI_Monogram_Color_API_URL' => 'https://tsaas.textronic.online/v1/MonogramColor?',
];
